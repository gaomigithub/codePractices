package lab4;

import java.util.Collections;

public class SJFScheduler extends Scheduler {

}
