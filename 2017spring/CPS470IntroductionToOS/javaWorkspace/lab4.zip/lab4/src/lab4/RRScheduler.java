package lab4;

import java.util.Collections;

public class RRScheduler extends Scheduler {

}
