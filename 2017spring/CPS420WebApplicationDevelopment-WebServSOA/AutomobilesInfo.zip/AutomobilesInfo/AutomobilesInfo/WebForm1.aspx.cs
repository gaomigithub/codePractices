﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AutomobilesInfo
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private Automobile ao;
        private ArrayList automobiles = new ArrayList();
        private ArrayList aoNames = new ArrayList();

        void Page_PreRender(object sender, EventArgs e)
        {
            Session.Add("Automobiles", automobiles);

        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //if (ViewState["Companies"] != null)
                if (Session["Automobiles"] != null)
                {
                    automobiles = (ArrayList)Session["Automobiles"];
                }
                else
                    automobiles = CreateAutomobiles();
                PopulateDropdownList();
            }
        }

        public ArrayList CreateAutomobiles()
        {
            ArrayList aos = new ArrayList();
            aos.Add(new Automobile() { Make = "Subaru", Model = "Forester", Price = 2000, Year = 2014, Color = "Blue", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Mitsubishi", Model = "Outlander", Price = 2000, Year = 2014, Color = "Silver", Description = "SUV" });
            aos.Add(new Automobile() { Make = "BMW", Model = "X1", Price = 2000, Year = 2014, Color = "Black", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Audi", Model = "Q5", Price = 2000, Year = 2014, Color = "Silver", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Toyota", Model = "Highlander", Price = 2000, Year = 2014, Color = "Red", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Nissan", Model = "Rogue", Price = 2000, Year = 2014, Color = "Red", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Benz", Model = "GLK-Class", Price = 2000, Year = 2014, Color = "Black", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Buick", Model = "Encore", Price = 2000, Year = 2014, Color = "Copper", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Nissan", Model = "JUKE", Price = 2000, Year = 2014, Color = "Black", Description = "SUV" });
            aos.Add(new Automobile() { Make = "Mazida", Model = "CX-5", Price = 2000, Year = 2014, Color = "Silver", Description = "SUV" });
            return aos;
        }

        protected void populateTextBoxes(Automobile ao)
        {
            txtMake.Text = ao.Make;
            txtModel.Text = ao.Model;
            txtPrice.Text = ao.Price.ToString();
            txtYear.Text = ao.Year.ToString();
            txtColor.Text = ao.Color.ToString();
            txtDescription.Text = ao.Description;
           
        }

        protected void PopulateDropdownList()
        {
            for (int i = 0; i < automobiles.Count; ++i)
            {
                Automobile ao = (Automobile)automobiles[i];
                aoNames.Add(ao.Make + "-" + ao.Model);
            }
            lstAutomobiles.DataSource = aoNames;
            lstAutomobiles.DataBind();
        }

        protected void lstAutomobiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            automobiles = (ArrayList)Session["Automobiles"];
            int index;
            index = lstAutomobiles.SelectedIndex;
            //Response.Write(index);
            Automobile ao = (Automobile)automobiles[index];
            populateTextBoxes(ao);
        }

        protected void btnNewAutomobile_Click(object sender, EventArgs e)
        {
            automobiles = (ArrayList)Session["Automobiles"];
            automobiles.Add(new Automobile() { Make = txtMake.Text,Model=txtModel.Text,Price=double.Parse( txtPrice.Text),Year=int.Parse(txtYear.Text),Color=txtColor.Text,Description=txtDescription.Text });
            Session["Automobiles"] = automobiles;
            PopulateDropdownList();

            txtMake.Text = "";
            txtModel.Text = "";
            txtPrice.Text = "";
            txtYear.Text = "";
            txtColor.Text = "";
            txtDescription.Text = "";
        }
    }
}